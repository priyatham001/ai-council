/**
 * KrishiSetu — Global Language Context
 *
 * Single source of truth for the selected language.
 * All components that need language should use useLanguage() from this context.
 * localStorage key: 'krishi_language'
 */

import React, { createContext, useContext, useState, useCallback, useEffect, ReactNode } from 'react';
import { Language } from '../types/krishi';
import { TRANSLATIONS, SUPPORTED_LANGUAGES, type Translations } from '../utils/i18n';

// Re-export so consumers have one import
export type { Language, Translations };
export { SUPPORTED_LANGUAGES };

interface LanguageContextValue {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
  /** Translate with a fallback string — safe shorthand */
  tr: (key: keyof Translations, fallback?: string) => string;
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined);

const LS_KEY = 'krishi_language';

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLangState] = useState<Language>(() => {
    const saved = localStorage.getItem(LS_KEY) as Language | null;
    // Validate: only accept supported codes
    if (saved && SUPPORTED_LANGUAGES.some(l => l.code === saved)) return saved;
    return 'en';
  });

  const setLanguage = useCallback((lang: Language) => {
    setLangState(lang);
    localStorage.setItem(LS_KEY, lang);
    // Also write to the agrilink storage service key so AppNavbar stays in sync
    localStorage.setItem('smartagrilink_lang', lang);
    // Dispatch event for legacy components listening on storage events
    window.dispatchEvent(new StorageEvent('storage', { key: LS_KEY, newValue: lang }));
    window.dispatchEvent(new CustomEvent('krishi_language_changed', { detail: lang }));
  }, []);

  // Listen for changes from legacy components (AppNavbar writes to smartagrilink_lang)
  useEffect(() => {
    const handleLegacyChange = () => {
      const legacy = localStorage.getItem('smartagrilink_lang') as Language | null;
      if (legacy && legacy !== language && SUPPORTED_LANGUAGES.some(l => l.code === legacy)) {
        setLangState(legacy);
        localStorage.setItem(LS_KEY, legacy);
      }
    };
    window.addEventListener('smartagrilink_lang_changed', handleLegacyChange);
    return () => window.removeEventListener('smartagrilink_lang_changed', handleLegacyChange);
  }, [language]);

  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const tr = useCallback(
    (key: keyof Translations, fallback?: string): string => {
      const val = t[key];
      if (typeof val === 'string') return val;
      return fallback ?? String(key);
    },
    [t]
  );

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, tr }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextValue => {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used inside <LanguageProvider>');
  return ctx;
};

// Alias for components using the old name
export const useTranslation = useLanguage;
